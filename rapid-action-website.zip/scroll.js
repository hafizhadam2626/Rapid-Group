// Simple intersection observer to add .visible class to .fade-up elements
document.addEventListener('DOMContentLoaded', function() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = 1;
        entry.target.style.transform = 'translateY(0)';
      }
    });
  }, {threshold: 0.15});

  document.querySelectorAll('.fade-up').forEach(el => observer.observe(el));
});